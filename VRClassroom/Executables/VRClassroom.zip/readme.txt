During the development with NOD it showed the following problems:

� The NOD process consumes more than 98% of the CPU, this happens in a desktop computer with 4GB RAM and an Intel Core 2 6300 @ 1.83 GHz processor with Windows 8.1.

� After 5 or 6 tests in Unity 3D, the NOD stops working and requires in some cases to restart Unity, and in other cases to restart the computer to work again.

� After a few attempts the NOD�s buttons do not respond, while the gestures or changes of position were still recognized, being necessary to restart the computer.

� The NOD ring have some compatibilities conflict whith the oculus rift in the unity editor in the plug-in file.


How to use:

To select language: Use the button at the left of the NOD symbol

To reset camera position: Make a tap in the trackpad

To go fordward: Use the button at the left of the NOD symbol

To go backward: Use the button at the right of the NOD symbol

To record a question: Raise your hand

To stop the record: Get your hand down